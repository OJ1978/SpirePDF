﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Spire.Pdf;
using System.Drawing;
using Spire.Pdf.Widget;
using Spire.Pdf.Fields;
using System.Threading;
using Spire.Pdf.HtmlConverter;


namespace PDF
{
    class Program
    {
        static void Main(string[] args)
        {

            //Create a pdf document.
            PdfDocument doc = new PdfDocument();

            PdfPageSettings setting = new PdfPageSettings();

            setting.Size = new SizeF(1000, 1000);
            setting.Margins = new Spire.Pdf.Graphics.PdfMargins(20);

            PdfHtmlLayoutFormat htmlLayoutFormat = new PdfHtmlLayoutFormat();
            htmlLayoutFormat.IsWaiting = true;

            String url = "https://www.wikipedia.org/";

            Thread thread = new Thread(() =>
            { doc.LoadFromHTML(url, false, false, false, setting, htmlLayoutFormat); });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            //Save pdf file.
            doc.SaveToFile("output-wiki.pdf");
            doc.Close();
            //Launching the Pdf file.
            System.Diagnostics.Process.Start("output-wiki.pdf");
        }
    }
}